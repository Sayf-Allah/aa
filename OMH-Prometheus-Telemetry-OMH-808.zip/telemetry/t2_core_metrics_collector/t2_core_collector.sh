
!/bin/sh

# nsenter -t 1 -n -m


working_dir=/u01/app/oracle/tools/t2_ccc_metrics_collector
SLEEPTIME=30

cd $working_dir

# if file is located somewhere else please mention the correct directory
python_script="$working_dir/t2_python.py"   #python script to send data to telemetry 
hostname=$(hostname)

#Assigning the region based on hostname
function check_region() {
    
    local hostname=$1
    
    # Define the region map
   
    map_json='{
        "iad": "us-ashburn-1",
        "bom": "ap-mumbai-1",
        "frk": "eu-frankfurt-1",
        "icn": "ap-seoul-1",
        "lhr": "uk-london-1",
        "nrt": "ap-tokyo-1",
        "phx": "us-phoenix-1",
        "syd": "ap-sydney-1",
        "yyz": "ca-toronto-1",
        "gru": "sa-saopaulo-1",
        "zrh": "eu-zurich-1",
        "jed": "me-jeddah-1"
    }'

    # Iterate over the JSON key-value pairs
    for key in $(echo "$map_json" | jq -r 'keys[]'); do

        # Check if the hostname contains the key
        if [[ $hostname == *"$key"* ]]; then        
             region=$(echo "$map_json" | jq -r ".$key")
             return
        fi
        
    done

}

# Call the function with the provided hostname
check_region "$hostname"


function metrics_data
{
    local metric_name="$1"
    local value="$2"
    
    #if value is numerical add in outjson
    if echo "$value" | grep -qE '^[0-9]+([.][0-9]+)?$'; then
           outjson=$(echo "$outjson" | jq --arg key "$metric_name" --argjson value "$value" '.metrics_data += {($key): $value}')         
    fi
       
    
}


function system_metrics ()
{
    
            #CPU usage
            cpu_info=$(top -bn1 | grep -E -m 1 '(%Cpu\(s\): |Cpu\(s\): )')
            format=$(echo "$cpu_info" | awk '{print $1}')

            if [ "$format" = "%Cpu(s):" ]; then
            # Format: %Cpu(s): 3.0 us, 3.0 sy, 0.0 ni, 93.9 id, 0.0 wa, 0.0 hi, 0.0 si, 0.0 st
            total_cpu_usage=$(echo "$cpu_info" | awk '{usage=100-$8} END {print usage}')
            else
            # Format: Cpu(s): 4.8%us, 5.2%sy, 0.2%ni, 89.5%id, 0.1%wa, 0.0%hi, 0.1%si, 0.0%st
            total_cpu_usage=$(echo "$cpu_info" | awk '{gsub(/%.*/, "", $2); usage=100-$5} END {print usage}')
            fi

            metrics_data "CPU_Usage_percent" "$total_cpu_usage"


            #----CPU INFO-----
            # Get the number of CPUs on the system
            cpu_count=$(grep -c '^processor' /proc/cpuinfo)

            # Get the clock tick rate
            #Using this beacuse /proc/stat gives output in jiffies and to change output it in seconds 
            clock_tick_rate=$(getconf CLK_TCK)

            # Iterate over each CPU
            for ((cpu=0; cpu<cpu_count; cpu++))
            do
                cpu_idle=$(cat /proc/stat | grep "^cpu$cpu " | awk '{print $5}')
                cpu_iowait=$(cat /proc/stat | grep "^cpu$cpu " | awk '{print $6}')
                cpu_irq=$(cat /proc/stat | grep "^cpu$cpu " | awk '{print $7}')
                cpu_nice=$(cat /proc/stat | grep "^cpu$cpu " | awk '{print $3}')
                cpu_softirq=$(cat /proc/stat | grep "^cpu$cpu " | awk '{print $8}')
                cpu_steal=$(cat /proc/stat | grep "^cpu$cpu " | awk '{print $9}')
                cpu_system=$(cat /proc/stat | grep "^cpu$cpu " | awk '{print $4}')
                cpu_user=$(cat /proc/stat | grep "^cpu$cpu " | awk '{print $2}')
                cpu_guest_nice=$(cat /proc/stat | grep "^cpu$cpu " | awk '{print $11}')
                cpu_guest_user=$(cat /proc/stat | grep "^cpu$cpu " | awk '{print $10}')
                
                metrics_data "cpu_seconds_total_cpu_${cpu}_mode_idle" "$(echo "scale=2; $cpu_idle / $clock_tick_rate" | bc)"
                metrics_data "cpu_seconds_total_cpu_${cpu}_mode_iowait" "$(echo "scale=2; $cpu_iowait / $clock_tick_rate" | bc)"
                metrics_data "cpu_seconds_total_cpu_${cpu}_mode_irq" "$(echo "scale=2; $cpu_irq / $clock_tick_rate" | bc)"
                metrics_data "cpu_seconds_total_cpu_${cpu}_mode_nice" "$(echo "scale=2; $cpu_nice / $clock_tick_rate" | bc)"
                metrics_data "cpu_seconds_total_cpu_${cpu}_mode_softirq" "$(echo "scale=2; $cpu_softirq / $clock_tick_rate" | bc)"
                metrics_data "cpu_seconds_total_cpu_${cpu}_mode_steal" "$(echo "scale=2; $cpu_steal / $clock_tick_rate" | bc)"
                metrics_data "cpu_seconds_total_cpu_${cpu}_mode_system" "$(echo "scale=2; $cpu_system / $clock_tick_rate" | bc)"
                metrics_data "cpu_seconds_total_cpu_${cpu}_mode_user" "$(echo "scale=2; $cpu_user / $clock_tick_rate" | bc)"
                metrics_data "cpu_guest_seconds_total_cpu_${cpu}_mode_nice" "$(echo "scale=2; $cpu_guest_nice / $clock_tick_rate" | bc)"
                metrics_data "cpu_guest_seconds_total_cpu_${cpu}_mode_user" "$(echo "scale=2; $cpu_guest_user / $clock_tick_rate" | bc)"
            done



            #----File Descriptor Metrics-----
            filefd_allocated=$(cat /proc/sys/fs/file-nr | awk '{print $1}')
            filefd_maximum=$(cat /proc/sys/fs/file-nr | awk '{print $3}')

            metrics_data "Filefd_allocated" "$filefd_allocated"
            metrics_data "Filefd_maximum" "$filefd_maximum"



            #----Memory Metrics----
            #Using /proc/meminfo

            while IFS=':' read -r name value; do

            # Remove leading/trailing spaces
            name=$(echo "$name" | tr -d ' ')
            value=$(echo "$value" | tr -d ' '|  tr -d '[:alpha:]' | awk '{print $1}')

            #Converting name as telemetry cannot have "()" in metrics name 
            new_name=$(echo "$name" | sed 's/(/_/;s/)//')

            # Convert values to bytes as by default its in KB
            value_bytes=$(($value * 1024))
            
            metrics_data "${new_name}_memory_in_bytes" "$value_bytes"

            done < /proc/meminfo



            #------FileSystem Info-----

            # Get filesystem information
            filesystem_info=$(df -B1 --output=avail,used,size,source,target,fstype,iavail,itotal | tail -n +2)

            # Iterate over each filesystem
            while read -r avail used size source target fstype iavail itotal; do

            # Applying condition to ignore specific mount points and filesystem types
            if [[ $target =~ ^(\/proc|\/sys|\/var\/lib\/docker) || $fstype =~ ^(autofs|binfmt_misc|cgroup|configfs|debugfs|devpts|devtmpfs|fusectl|hugetlbfs|mqueue|nfs|nsfs|overlay|proc|procfs|pstore|rootfs|rpc_pipefs|securityfs|selinuxfs|sysfs|tracefs|tmpfs|vfat)$ ]]; then
                continue
            fi
            
            mount_point="$target"
            # needs to convert mount point as telemetry metrics name 
            #cannot have "/" in name so we will replace "/" with "."
            # Valid Characters: Alphanumeric characters, periods, underscores, hyphens, dollar
            # E.g. /u01/app/oracle/tools to .u01.app.oracle.tools
            converted_mount_point=${mount_point//\//.}
            
            #echo "Filesystem Type: $fstype", No need to send this as we have already apllied conditon based on this 
            
            #Available bytes
            metrics_data "Filesystem_avail_bytes_mountpoint_${converted_mount_point}" "$avail"
            #Free bytes
            free_bytes=$((${size} -${used}))
            metrics_data "Filesystem_free_bytes_mountpoint_${converted_mount_point}" "$free_bytes"
            #size that is total size
            metrics_data "Filesystem_size_bytes_mountpoint_${converted_mount_point}"  "$size"
            #file
            metrics_data "Filesystem_files_mountpoint_${converted_mount_point}"  "$itotal"
            #file free
            metrics_data "Filesystem_files_free_mountpoint_${converted_mount_point}"  "$iavail"
            # Check if filesystem is read-only
            readonly=$(mount | grep "$mount_point" | grep "(ro," >/dev/null && echo "1" || echo "0")
            metrics_data "Filesystem_read_only_mountpoint_${converted_mount_point}"  "$readonly"
            # Check for device errors
            device_errors=$(dmesg | grep "I/O error" | grep "$mount_point" | wc -l)
            metrics_data "Filesystem_device_error_mountpoint_${converted_mount_point}"  "$device_errors"

            
            done <<< "$filesystem_info"
}

function generate_process_metrics_file ()
{
    evaluation_start_time=$(date +%s)

    # Determine, and record, the process-count metric for commands in which we are interested
    #  we use ps to check for the OS managed processes
    #  we use jps to check for processes we know to be java
    #  we use docker ps to check for docker managed processes

    # Specific OS processes
    # ---------------------
    metric_name="amc_process_count"
    # HELP - Count of the the number of processes, of commands of interest, currently active on the host.
    command_names=("dockerd" "docker-proxy" "java")
    for c in "${command_names[@]}"
    do
      # Look for the presence of processes running the $c command
      # -o command= : reports the full command _and_ prevents the ps header output
      # -C $c       : reports only processes for executable $c
      process_count=$(ps -o command= -C $c | wc -l)
      metrics_data "${metric_name}_process_cmd_${c}" "$process_count" 
    done

    # Docker-managed processes
    # ------------------------
    # docker_statuses=("created" "restarting" "running" "removing" "paused" "exited" "dead")
    metric_name="amc_process_docker_count"
    # HELP - Count of the the number of docker-managed processes currently active on the host
    docker_health_types=("starting" "healthy" "unhealthy" "none")
    for s in "${docker_health_types[@]}"
    do
        # We use the format to prevent the normal header line from being output
        process_count=$(docker ps --format "{{.ID}}: {{.Command}}" --all --filter health=$s | wc -l)
        metrics_data "${metric_name}_docker_health_${s}" "$process_count" 
    done

    # Specific Java processes (by main class)
    # ---------------------------------------
    # We're looking specifically for "java" processes.
    # we may want to cache this jps output if we're going to be looking for
    # more than one class name
    metric_name="amc_process_java_count"
    # HELP - Count of the the number of java processes, with main classes of interest, currently active on the host."
    # old method using jps process_count=$(/u01/app/oracle/mobile/jdk1.8.0_161/bin/jps -l | grep "oracle.cloud.mobile.commonagent.MCSAgent" | wc -l)
    process_count=$(ps -eaf | grep oracle.cloud.mobile.commonagent.MCSAgent | wc -l)   
    # because ps returns itself in the process count we need to removed if from the reported
    process_count_adjusted=$(expr $process_count - 1)
    metrics_data "${metric_name}_main_class_MCSAgent" "$process_count_adjusted" 

    # Metrics for this-scripts-performance
    # ------------------------------------
    # Write the time at which this data was actively determined on the host
    metric_name="amc_process_inspection_evaluation_time"
    evaluation_end_time=$(date +%s)
    # HELP -Time, in epoch seconds, at which AMC process evaluation occurred
    metrics_data "$metric_name" "$evaluation_end_time"

    # Write the duration of this assessment
    metric_name="amc_process_inspection_evaluation_duration"
    evaluation_duration=$(( $evaluation_end_time - $evaluation_start_time ))
    # HELP Duration, in seconds, taken to complete AMC process evaluation"
    metrics_data "$metric_name" "$evaluation_duration"

    # Write the cgroup memory count, this is used to determine the status for ccc as described in OMH-118 and for implementation of OMH-119
    #  Due to a docker bug, memory usage in excess of 65535 can cause failure
    metric_name="amc_cgroup_memory_size"
    cgroup_memory_size=$(cat /proc/cgroups | grep memory | awk '{print $3}')
    # HELP- Memory size currently for the cgroup
    metrics_data "$metric_name" "$cgroup_memory_size"
}

tmp_dir=/tmp/t2_ccc_collect_metrics_$(date +"%Y%m%d_%H")_tmp
mkdir -p $tmp_dir

while true ;
do
    output_array=()
    outjson="{}"
    outjson=$(echo "$outjson" | jq ".fleet |= \"MobileStdCcc\"")
    outjson=$(echo "$outjson" | jq ".hostname |= \"$hostname\"")
    outjson=$(echo "$outjson" | jq ".region |= \"$region\"")

    # Rotate our outputs on an hourly basis
    next_tmp_dir=/tmp/t2_ccc_collect_metrics_$(date +"%Y%m%d_%H")_tmp
    if [ "$next_tmp_dir" != "$tmp_dir" ]
    then
      mkdir -p $next_tmp_dir
      log_file=${next_tmp_dir}/t2_metrics.log
      exec 2>&1 1>>${log_file}
      rm $tmp_dir/*
      rmdir $tmp_dir
      tmp_dir="$next_tmp_dir"
    else
      log_file=${tmp_dir}/t2_metrics.log
      exec 2>&1 1>>${log_file}
    fi

    collect_metrics=true

    

    if [ "$collect_metrics" == "true" ];
    then

            generate_process_metrics_file

            if [[ "$?" == "0" ]] ; then
                echo "$(date) Collected process metrics."
            else
                echo "$(date) Failed to collect process metrics."
            fi

            system_metrics

            if [[ "$?" == "0" ]] ; then
                echo "$(date) Collected system metrics."
            else
                echo "$(date) Failed to collect system metrics."
            fi
    fi

    echo "$outjson"
    output_array+=$outjson
    array_string=$(printf '%s\n' "${output_array[@]}" | jq -s '.')
    python $python_script "$array_string"

    sleep ${SLEEPTIME}

done
# end of file
