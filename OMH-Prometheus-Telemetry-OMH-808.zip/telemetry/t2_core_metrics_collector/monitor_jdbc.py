
print 'DB connection check:'
connect(sys.argv[1], sys.argv[2], sys.argv[3])
allServers=domainRuntimeService.getServerRuntimes();
if (len(allServers) > 0):
  for tempServer in allServers:
    print 'ServerName: ', tempServer.getName()
    jdbcServiceRT = tempServer.getJDBCServiceRuntime();
    dataSources = jdbcServiceRT.getJDBCDataSourceRuntimeMBeans();
    if (len(dataSources) == 0):
      print 'DB connection check failed, no datasources!'
      sys.exit(1);
    else:
      for dataSource in dataSources:
        print 'Name: '  , dataSource.getName(), "State: ", dataSource.getState()
        if (dataSource.getState() != 'Running'):
          print 'DB Connection check failed, not all datasources are running!'
          sys.exit(1);

print 'DB connection check success!'
