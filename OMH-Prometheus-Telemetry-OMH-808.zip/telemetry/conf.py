

'''this project name may differ so change it accordingly'''
PROJECT = "apip-cp-dev"
AVAILABILITY_DOMAIN = "iad-ad-1"
CERT_PATH = '/home/opc/telemetry/certi.pem'


'''telemetry endpoints selected based on region'''
TELEMETRY_ENDPOINT = {
    "us-ashburn-1": "https://telemetry.us-ashburn-1.oracleiaas.com/v1/public/series",
    "us-phoenix-1": "https://telemetry.r2.oracleiaas.com/v1/public/series",
    "uk-london-1": "https://telemetry.uk-london-1.oracleiaas.com/v1/public/series",
    "eu-frankfurt-1": "https://telemetry.eu-frankfurt-1.oracleiaas.com/v1/public/series",
    "ap-mumbai-1": "https://telemetry.ap-mumbai-1.oracleiaas.com/v1/public/series",
    "ap-seoul-1": "https://telemetry.ap-seoul-1.oracleiaas.com/v1/public/series",
    "ap-tokyo-1": "https://telemetry.ap-tokyo-1.oracleiaas.com/v1/public/series",
    "ap-sydney-1": "https://telemetry.ap-sydney-1.oracleiaas.com/v1/public/series",
    "ca-toronto-1": "https://telemetry.ca-toronto-1.oracleiaas.com/v1/public/series",
    "sa-saopaulo-1": "https://telemetry.sa-saopaulo-1.oracleiaas.com/v1/public/series",
    "eu-zurich-1": "https://telemetry.eu-zurich-1.oracleiaas.com/v1/public/series",
    "me-jeddah-1": "https://telemetry.me-jeddah-1.oracleiaas.com/v1/public/series",




}

'''uncomment this part once u have the details of availability domain of regions where u want to push the metrics
for now we are using "iad-ad-1" '''

# AVAILABILITY_DOMAIN = {
#     "ASH_PR": "iad-ad-1",
#     "PHX_PR": "phx-ad-1",
#     "LON_PR": "lhr-ad-1",
#     "FRA_PR": "fra-ad-1",
#     "PHX_ST": "phx-ad-1",
#     "LON_ST": "lhr-ad-1",
#     "FRA_ST": "fra-ad-1"
# }



