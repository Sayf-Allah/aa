
import json
from time import sleep, time
import sys
import logging
import requests
from oci.auth.signers import InstancePrincipalsSecurityTokenSigner
from conf import *
 
 
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
 
# Create a file handler and set the log file path
log_file = 'T2.log'
file_handler = logging.FileHandler(log_file)
 
 
# Configure the log message format
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
 
 
# Add the file handler to the logger
logger.addHandler(file_handler)
 
 
class TelemetryClient:
 
    def __init__(self):
 
        self.sign = self.signer()
        self._session = requests.Session()
        self._endpoint = ""
        self._session.headers.update(
            {"Content-Type": "application/json", "Accept": "application/json"})
        self._session.verify = CERT_PATH
        self._session.auth = self.sign
 
 
    def signer(self):
        """Used to get a signed token from the identity endpoint."""
 
        return InstancePrincipalsSecurityTokenSigner()
 
 
    def get_timestamp(self):
 
        """To get the epoch timestamp in ms"""
        return int(time())
 
 
    def format_metric(self, metrics_payload):
        output_payload_array = []
 
        for metrics in metrics_payload:
            output_metric_data = []
 
            metrics_data = metrics["metrics_data"]
 
            for data in metrics_data:
                """Actual metric data formation"""
                output_data = {
                    "name": data,
                    "metricType": "gauge",
                    "series": [
                        {
                            "second": self.get_timestamp(),
                            "values": [{"value": metrics_data[data], "count": 1}]
                        }
                    ]
                }
 
                output_metric_data.append(output_data)
 
            self._endpoint = TELEMETRY_ENDPOINT.get(metrics["region"]) # to get specific t2 endpoint depending on region
 
           
           #Formatting the T2 payload
            output_payload = {
                "project": PROJECT,
                "fleet": metrics["fleet"],
                "hostname": metrics["hostname"],
                "region": metrics["region"],
                "availabilityDomain": AVAILABILITY_DOMAIN,
                "metrics": output_metric_data
            }
 
            output_payload_array.append(output_payload)
 
        return output_payload_array
 
    def emit(self, output_payload):
        # print("Sending the metrics to the T2")
        request_text = json.dumps(output_payload)
        logger.debug("Sending %s to T2", request_text)
 
        try:
            response = self._session.put(self._endpoint, request_text)
            logger.info("Received response from T2: %s - %s",
                        response.headers, response.content)
        except Exception as e:
            logger.error('Unable to send request! with the error:- %s', e)
 
    def send_payload(self, payload):
        for data in payload:
            self.emit(data)
            sleep(30)
 
    def submit(self):
        argv_data = sys.argv[1]  # json_data_which_needs_to_be_formatted
        metrics_payload = json.loads(argv_data)
        # for checking u can comment out above 2 lines and uncomment the below one 
        # metrics_payload = [      
        #     {
        #         "fleet": "MobileStdCore",
        #         "hostname": "mobv3dediad1i0013hdadb3cmspd-wls-1",
        #         "region": "us-ashburn-1",
        #         "metrics_data": {
        #         "amc_process_count_process_cmd_java": 5,
        #         "amc_process_wls_count_wls_process_type_admin_server": 1,
        #         "amc_process_wls_count_wls_process_type_node_manager": 1,
        #         "amc_process_wls_count_wls_process_type_server": 2,
        #         "amc_process_inspection_evaluation_time": 1689522352,
        #         "amc_process_inspection_evaluation_duration": 0,
        #         "amc_minimum_billing_payload_count": 1,
        #         "amc_minimum_billing_payload_size": 0,
        #         "amc_metering_billing_payload_size": 0,
        #         "amc_db_connection": 1,
        #         "amc_lbr_connection": 1,
        #         "CPU_Usage_percent": 21.33,
        #         "cpu_seconds_total_cpu_0_mode_idle": 766796.19,
        #         "cpu_seconds_total_cpu_0_mode_iowait": 667.75,
        #         "cpu_seconds_total_cpu_0_mode_irq": 0
        #         } 
        #      } 
        # ]
        payload = self.format_metric(metrics_payload)
        self.send_payload(payload)
 
 
if __name__ == "__main__":
    client = TelemetryClient()
    client.submit()

