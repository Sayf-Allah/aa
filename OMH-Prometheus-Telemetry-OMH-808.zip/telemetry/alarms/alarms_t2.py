

import json
from time import sleep, time
import sys
import logging
import requests
from oci.auth.signers import InstancePrincipalsSecurityTokenSigner

from conf import *
logger = logging.getLogger(__name__)

logger.setLevel(logging.INFO)

# Create a file handler and set the log file path
log_file = 'alarms.log'
file_handler = logging.FileHandler(log_file)

# Configure the log message format
formatter = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)

# Add the file handler to the logger
logger.addHandler(file_handler)


class TelemetryClient:

    def __init__(self):
        self.sign = self.signer()
        self._session = requests.Session()
        #change endpoint as per the region , this endpoint is for ashburn region
        self._endpoint = "https://telemetry.us-ashburn-1.oracleiaas.com/v2/alarms"
        self._session.headers.update(
            {"Content-Type": "application/json", "Accept": "application/json"})
        self._session.verify = CERT_PATH
        self._session.auth = self.sign

    def signer(self):
        """Used to get a signed token from the identity endpoint."""
        # Implement your logic to obtain the appropriate signer
        # ...
        return InstancePrincipalsSecurityTokenSigner()

    def get_timestamp(self):
        """To get the epoch timestamp in ms"""
        return int(time())

    def format_metric(self, metrics_payload):
        output_payload_array = []
        # TODO we cna format the alarms payload here
        return output_payload_array

    def emit(self, output_payload):
        # print("Sending the metrics to the T2")
        request_text = json.dumps(output_payload)
        logger.debug("Sending %s to alarms", request_text)
        try:
            response = self._session.post(self._endpoint, request_text)
            logger.info("Received response from T2 alarms: %s - %s",
                        response.headers, response.content)
        except Exception as e:
            logger.error('Unable to send request! with the error:- %s', e)

    # can be used if we have more than 1 alarm
    # def send_payload(self, payload):
    #     for data in payload:
    #         self.emit(data)
    #         sleep(30)

    def submit(self):
        metrics_payload =     {
        "compartmentId": COMPARTMENTID,
        "displayName": "DB_Listener_Down",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "amc_db_connection[1m].max()==0",
        "severity": 2,
        "isEnabled": True,
        "dedupeKey": "DBListener_Down",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     }
        # payload = self.format_metric(metrics_payload)
        # self.send_payload(payload)
        self.emit(metrics_payload)


if __name__ == "__main__":
    client = TelemetryClient()
    client.submit()

