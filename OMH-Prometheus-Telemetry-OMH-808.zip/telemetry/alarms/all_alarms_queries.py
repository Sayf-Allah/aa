#This script conatins all alarms ,u have to use python script to post this for all endpoints
alarms=[
    #---core instance------
    {
        "compartmentId": COMPARTMENTID,
        "displayName": "CoreServer-AdminServer_Down",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "amc_process_wls_count_wls_process_type_admin_server[2m]{host =~ '*mspd-wls-1'}.max()<1",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CoreServer-AdminServer_Down",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "CoreServer-wls-1_Down",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "amc_process_wls_count_wls_process_type_server[2m]{host =~ '*mspd-wls-1'}.max()<2",
        "severity": 2,
        "isEnabled": True,
        "dedupeKey": "CoreServer-wls-1_Down",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "CoreServer-wls-2_Down",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "amc_process_wls_count_wls_process_type_server[2m]{host =~ '*mspd-wls-2'}.max()<1",
        "severity": 2,
        "isEnabled": True,
        "dedupeKey": "CoreServer-wls-2_Down",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "CoreServer-wls-3_Down",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "amc_process_wls_count_wls_process_type_server[2m]{host =~ '*mspd-wls-3'}.max()<1",
        "severity": 2,
        "isEnabled": True,
        "dedupeKey": "CoreServer-wls-3_Down",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "CoreServer-wls-4_Down",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "amc_process_wls_count_wls_process_type_server[2m]{host =~ '*mspd-wls-4'}.max()<1",
        "severity": 2,
        "isEnabled": True,
        "dedupeKey": "CoreServer-wls-4_Down",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "CoreServer-Node_Manager_Down",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "amc_process_wls_count_wls_process_type_node_manager[10m].max()<1",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CoreServer_Node_Manager_Down",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "DB_Listener_Down",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "amc_db_connection[2m].max()==0",
        "severity": 2,
        "isEnabled": True,
        "dedupeKey": "DBListener_Down",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "Public_LBR_Down",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "amc_lbr_connection[2m].max()==0",
        "severity": 2,
        "isEnabled": True,
        "dedupeKey": "PublicLBR_Down",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "Minimum_Billing_Payload_Warning",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "amc_minimum_billing_payload_count[10m].max()>1",
        "severity": 3,
        "isEnabled": True,
        "body":
        "The number of threads submitting miniumum billing payloads has exceeded 1, only 1 thread should be submitting minimum billing payloads. The patch for OMH-178 should be applied.",
        "dedupeKey": "Minimum_Billing_Payload_Warning",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "Swap memory consumption on Core Server has exceeded 80%",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "( ( 1 - (SwapFree_memory_in_bytes[1m].mean() / SwapTotal_memory_in_bytes[1m].mean() ) ) * 100 )>80",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CoreSwapMem_Consumption_Warning",
        "pendingDuration": "PT5M",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": " Available memory on Core Server is below 20%",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "( ( MemAvailable_memory_in_bytes[1m].mean() / MemTotal_memory_in_bytes[1m].mean()) * 100)<20",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CoreAvailable_Memory_Warning",
        "pendingDuration": "PT5M",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "Core FileSystem FreeSpace below 20% , Mount Point ='/' ",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "( Filesystem_avail_bytes_mountpoint_.[1m].mean() / Filesystem_size_bytes_mountpoint_.[1m].mean())<0.2",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CoreFileSystem_FreeSpace_Warning",
        "pendingDuration": "PT10M",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "Core FileSystem FreeSpace below 20% , Mount Point ='/u01/data/domains' ",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "( Filesystem_avail_bytes_mountpoint_.u01.data.domains[1m].mean() / Filesystem_size_bytes_mountpoint_.u01.data.domains[1m].mean())<0.2",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CoreFileSystem_FreeSpace_Warning",
        "pendingDuration": "PT10M",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "Core FileSystem FreeSpace below 20% , Mount Point ='/u01/em' ",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "( Filesystem_avail_bytes_mountpoint_.u01.em[1m].mean() / Filesystem_size_bytes_mountpoint_.u01.em[1m].mean())<0.2",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CoreFileSystem_FreeSpace_Warning",
        "pendingDuration": "PT10M",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },
    
    {
        "compartmentId": COMPARTMENTID,
        "displayName": "Core FileSystem FreeSpace below 20% , Mount Point ='/u01/app/oracle/tools' ",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "( Filesystem_avail_bytes_mountpoint_.u01.app.oracle.tools[1m].mean() / Filesystem_size_bytes_mountpoint_.u01.app.oracle.tools[1m].mean())<0.2",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CoreFileSystem_FreeSpace_Warning",
        "pendingDuration": "PT10M",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "Core FileSystem FreeSpace below 20% , Mount Point ='/u01/app/oracle/middleware' ",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "( Filesystem_avail_bytes_mountpoint_.u01.app.oracle.middleware[1m].mean() / Filesystem_size_bytes_mountpoint_.u01.app.oracle.middleware[1m].mean())<0.2",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CoreFileSystem_FreeSpace_Warning",
        "pendingDuration": "PT10M",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "Core FileSystem FreeSpace below 20% , Mount Point ='/u01/jdk' ",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "( Filesystem_avail_bytes_mountpoint_.u01.jdk[1m].mean() / Filesystem_size_bytes_mountpoint_.u01.jdk[1m].mean())<0.2",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CoreFileSystem_FreeSpace_Warning",
        "pendingDuration": "PT10M",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "Core FileSystem FreeSpace below 20% , Mount Point ='/u01/data/backup' ",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "( Filesystem_avail_bytes_mountpoint_.u01.data.backup[1m].mean() / Filesystem_size_bytes_mountpoint_.u01.data.backup[1m].mean())<0.2",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CoreFileSystem_FreeSpace_Warning",
        "pendingDuration": "PT10M",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "Core FileSystem FreeSpace below 20% , Mount Point ='/u01/app/oracle/suite' ",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "( Filesystem_avail_bytes_mountpoint_.u01.app.oracle.suite[1m].mean() / Filesystem_size_bytes_mountpoint_.u01.app.oracle.suite[1m].mean())<0.2",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CoreFileSystem_FreeSpace_Warning",
        "pendingDuration": "PT10M",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "CPU Usage on Core VM has breached the threshold of 80%",
        "project": PROJECT,
        "fleet": "{}.MobileStdCore".format(TENANCY),
        "query":
        "CPU_Usage_percent[5m].max()>80",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "Core_CPU_Warning",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

     #------ccc instance---

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "Swap memory consumption on CCC Server has exceeded 80%",
        "project": PROJECT,
        "fleet": "{}.MobileStdCcc".format(TENANCY),
        "query":
        "( ( 1 - (SwapFree_memory_in_bytes[1m].mean() / SwapTotal_memory_in_bytes[1m].mean() ) ) * 100 )>80",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CCCSwapMem_Consumption_Warning",
        "pendingDuration": "PT5M",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": " Available memory on CCC Server is below 20%",
        "project": PROJECT,
        "fleet": "{}.MobileStdCcc".format(TENANCY),
        "query":
        "( ( MemAvailable_memory_in_bytes[1m].mean() / MemTotal_memory_in_bytes[1m].mean()) * 100)<20",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CCCAvailable_Memory_Warning",
        "pendingDuration": "PT5M",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "CCC FileSystem FreeSpace below 20% , Mount Point ='/' ",
        "project": PROJECT,
        "fleet": "{}.MobileStdCcc".format(TENANCY),
        "query":
        "( Filesystem_avail_bytes_mountpoint_.[1m].mean() / Filesystem_size_bytes_mountpoint_.[1m].mean())<0.2",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CCCFileSystem_FreeSpace_Warning",
        "pendingDuration": "PT10M",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "CCC FileSystem FreeSpace below 20% , Mount Point ='/u01/app/oracle/tools' ",
        "project": PROJECT,
        "fleet": "{}.MobileStdCcc".format(TENANCY),
        "query":
        "( Filesystem_avail_bytes_mountpoint_.u01.app.oracle.tools[1m].mean() / Filesystem_size_bytes_mountpoint_.u01.app.oracle.tools[1m].mean())<0.2",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "CCCFileSystem_FreeSpace_Warning",
        "pendingDuration": "PT10M",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "CGroups_memory_usage_exceeds_limit",
        "project": PROJECT,
        "fleet": "{}.MobileStdCcc".format(TENANCY),
        "query":
        "amc_cgroup_memory_size[2m].min()>60000",
        "severity": 2,
        "isEnabled": True,
        "body":
        "The CGroups memory usage has exceeded the safe limit. This should be addressed with a restart or as defined in OMH-118",
        "dedupeKey": "CGroups_mem_usage_exceeds_limit",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "CCC Agent Down Alert",
        "project": PROJECT,
        "fleet": "{}.MobileStdCcc".format(TENANCY),
        "query":
        "amc_process_java_count_main_class_MCSAgent[2m].max()<1",
        "severity": 2,
        "isEnabled": True,
        "dedupeKey": "CCC_Agent_Down",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     },

    {
        "compartmentId": COMPARTMENTID,
        "displayName": "CPU Usage on CCC VM has breached the threshold of 80%",
        "project": PROJECT,
        "fleet": "{}.MobileStdCcc".format(TENANCY),
        "query":
        "CPU_Usage_percent[5m].max()>80",
        "severity": 3,
        "isEnabled": True,
        "dedupeKey": "Ccc_CPU_Warning",
        "isDedupeKeyCrossRegion": True,
         "destinations" : {
                      "jira" : {
                            "project" : "AMCE",
                            "component" : "Region Build",
                            "item" : "None"
                       }
           } 
     }


]
