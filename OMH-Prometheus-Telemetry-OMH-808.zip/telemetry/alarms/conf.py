PROJECT = "apip-cp-dev"
AVAILABILITY_DOMAIN = "iad-ad-1"
TENANCY="p2-apicsmtp2infra"
COMPARTMENTID="ocid1.compartment.oc1..aaaaaaaamio4pd57hdwzinvjc3tsiamlz42kvbeov2plezipcnt5exjkaawa"
CERT_PATH = '/home/opc/telemetry/certi.pem'
# REGION = {
#     "ASH_PR": "us-ashburn-1",
#     "PHX_PR": "us-phoenix-1",
#     "LON_PR": "uk-london-1",
#     "FRA_PR": "eu-frankfurt-1",
#     "PHX_ST": "us-phoenix-1",
#     "LON_ST": "uk-london-1",
#     "FRA_ST": "eu-frankfurt-1"
# }

